import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookformComponent } from './bookform/bookform.component';
import { BooklistComponent } from './booklist/booklist.component';
import { HomeComponent } from './home/home.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
//route mapping details


const routes: Routes = [
  
  {
    path:'',  //base-path - localhost:4200
    component:HomeComponent,
    pathMatch: 'full'
  },
  {
    path:'registerbook',
    component:BookformComponent
   },
  {
    path:'list-books',
    component:BooklistComponent
  },
  {
    path:'home',
    redirectTo:'',
  },
  {
    path:'**',
    component:PagenotfoundComponent
  }

];


// import the RouterModule into the current Module
// use forRoot() method of RouterModule to register your own routes with it
// export the modified RouterModule 
@NgModule({
  imports: [RouterModule.forRoot(routes)], 
  exports: [RouterModule]
})
export class AppRoutingModule { }
