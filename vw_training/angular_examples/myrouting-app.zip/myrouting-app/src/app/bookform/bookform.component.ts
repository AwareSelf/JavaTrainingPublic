import { Component, OnDestroy, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.css']
})
export class BookformComponent implements OnInit,OnDestroy{

   book:Book;
   bookdao:BookdaoService;

  constructor(bookdao:BookdaoService) { 

    this.bookdao = bookdao;
    
    this.book = new Book(this.bookdao.getLatestBookId(),'','');

  }

  ngOnInit(): void {
    console.log('Bookform component initialised');
  }

  addBook(bookid:string,bookname:string,bookauthor:string) :  void
  {
      var b:Book = new Book(+bookid,bookname,bookauthor);
      this.bookdao.addBook(b);
      this.book = new Book(+bookid+1,'','');
  }

  ngOnDestroy(): void {
      console.log('Bookform component about to be destroyed');
  }

}
