import { Component, OnDestroy, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit,OnDestroy {

  bookarr:Book[];
  bookdao:BookdaoService;

  constructor(bookdao:BookdaoService) { 
    this.bookarr = [];
    this.bookdao = bookdao;
  }

  ngOnInit(): void {
    console.log('booklist component initialised');
    this.bookarr = this.bookdao.getAllBooks();
  }

  ngOnDestroy(): void {
      console.log('book-list component about to be destroyed');
  }

}
