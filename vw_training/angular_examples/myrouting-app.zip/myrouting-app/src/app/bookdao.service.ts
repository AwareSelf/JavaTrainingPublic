import { Injectable } from '@angular/core';
import { Book } from './model/book';

@Injectable({
  providedIn: 'root'
})
export class BookdaoService {

   private bookarr:Book[]
  
  constructor() {

    this.bookarr = [];

   }

   addBook(b:Book):void
   {
      this.bookarr.push(b);
   }

   getAllBooks():Book[]
   {
      return  this.bookarr;
   }

   getLatestBookId():number
   {
      var size = this.bookarr.length;
      return size+1;

   }


}
