

import {Component} from '@angular/core';
import {Router} from '@angular/router';


@Component(
{
    selector:'app-root',
    template:`
      <h1> {{title}} </h1>

      <a routerLink='/registerbook' routerLinkActive="active" >Register Book</a>
      <a routerLink='/listallbooks' routerLinkActive="active"> List All Books </a>
      <a routerLink="/admin" routerLinkActive="active">Admin</a>
      
      <br><br>
      <hr>
      <p>Search Book </p>
      <input #n placeholder='enter bookid' />
      <button (click)='navSearch(n.value)'>SearchBook</button>

      <router-outlet></router-outlet>
        
    `

})
export class AppComponent
{
    title:string='Books App';
    router:Router;

    constructor(router:Router)
    {
       this.router=router;
    }

    navSearch(idval:number)
    {
        this.router.navigate(['searchbook',idval]);
    }


}


