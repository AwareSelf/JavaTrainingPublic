import {Book} from './book';

export class BookService
{
    bookarr:Book[]=[];

    addBook(b:Book)
    {
      this.bookarr.push(new Book(b.bookid,b.bookname,b.bookprice));
    }


    getAllBooks():Book[]
    {
        return this.bookarr.slice();
    }
}