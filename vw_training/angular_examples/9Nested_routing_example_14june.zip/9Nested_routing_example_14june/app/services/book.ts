export class Book
{

    constructor(public bookid:number,public bookname:string,public bookprice:number)
    {

    }
}