import {Component} from '@angular/core';
import {BookService} from './services/book.service';
import {Book} from './services/book';

@Component({
  selector:'register-book',
  template:` 
  
     <p> Register Book Component </p>
     <input [(ngModel)]='book.bookid' placeholder='Bookid' />
     <input [(ngModel)]='book.bookname' placeholder='BookName' />
     <input [(ngModel)]='book.bookprice' placeholder='BookPrice' />
     <button (click)='regBook(book)'>Register Book</button>
   
  `,
})
export class RegisterBook
{
  bookservice:BookService;
  book:Book;

   constructor(bookser:BookService)
   {
       this.book=new Book(1,'core java',200);
       this.bookservice=bookser;
   }

   regBook(b:Book)
   {
      this.bookservice.addBook(b);
      this.book=new Book(null,null,null);
   }

}