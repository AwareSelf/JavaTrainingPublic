

import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {RouterModule,Routes} from '@angular/router';
import {AppComponent} from './app.component';
import {RegisterBook} from './bookregister.component';
import {ListBooks} from './listbooks.component';
import {SearchComponent} from './search.component';
import {NotFound} from './notfound.component';
import {BookService} from './services/book.service';


const approutes:Routes =[
 {
     path:'registerbook',
     component:RegisterBook
    
 },
 {
     path:'listallbooks',
     component:ListBooks

 },
 {
    path:'searchbook/:id',
    component:SearchComponent
 },
 {
    path: 'admin',
    loadChildren: 'app/admin/admin.module#AdminModule',
    
  },
 {
      path:'',
      redirectTo:'/registerbook',
      pathMatch:'full'

 },
 {
     path:'**',
     component:NotFound
 }
];


@NgModule(
{
  imports:[
     BrowserModule,
     FormsModule,
     RouterModule.forRoot(approutes,{enableTracing:true})
  ],
  declarations:[
      AppComponent,
      RegisterBook,
      ListBooks,
      SearchComponent,
      NotFound

  ],
  providers:[BookService],
  bootstrap:[AppComponent]
}
)
export class AppModule
{

}