import {Component} from "@angular/core";
import {ActivatedRoute} from "@angular/router";
import {BookService} from './services/book.service';
import {Book} from './services/book';


@Component(
    {
        selector:'app-search-book',
        template:`
        
          <!--if id is not provided show errmsg-->
          <p> {{errmsg}}</p>


           <div *ngIf="msg">
             <p>{{msg}}</p>
           </div>

          <div *ngIf="foundbook"> 
           {{foundbook.bookid}} <br>
           {{foundbook.bookname}} <br>
           {{foundbook.bookprice}} <br>
           </div>
         
        `

    }
)
export class SearchComponent
{
    msg:string;
    foundbook:Book;
    errmsg:string;
    bookser:BookService;

    constructor(bookser:BookService, private route:ActivatedRoute)
    {
        this.bookser=bookser;
       
         this.route.params.subscribe( params => {
             if(params['id'])
             {
                 this.dosearch(params['id']);
             }
             else
             {
                 this.errmsg='please provide id!!';
             }

         });
   }

    dosearch(id:number)
    {
        this.foundbook=new Book(null,null,null);
        
        var flag:boolean =false;
        var bookarr:Book[];
        bookarr=this.bookser.getAllBooks();
        
        for(var i=0;i<bookarr.length;i++)
        {
            if(bookarr[i].bookid==id)
            {
                this.msg="Found the book!:BookDetails Below";
                this.foundbook= bookarr[i];
                flag=true;
                             
            }
        }

        if(flag==false)
        {
            this.msg="Book Not Found!";
        }
       
       
    }

}
