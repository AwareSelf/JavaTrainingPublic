import {Component} from '@angular/core';
import {BookService} from './services/book.service';
import {Book} from './services/book';

@Component({
  selector:'list-books',
  template:` 
  
     <p> List book component </p>

     <button (click)='listBooks()'>List All Books</button>
     <div *ngIf=bookarr>
        <table>
           <tr *ngFor = 'let b of bookarr'>
             <td> {{b.bookid}} </td>
             <td> {{ b.bookname}} </td>
             <td> {{ b.bookprice}} </td>
           </tr>
        </table>
     </div>

  `,
})
export class ListBooks
{
  bookarr:Book[];
  bookser:BookService;

   constructor(bookser:BookService)
   {
      this.bookser=bookser;
      this.bookarr=[];

   }

   listBooks()
   {
     this.bookarr=this.bookser.getAllBooks();
   }



}