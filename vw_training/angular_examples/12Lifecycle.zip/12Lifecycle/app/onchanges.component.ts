
import {
  Component, Input, OnChanges,OnInit,OnDestroy,AfterContentInit,AfterViewInit,
  SimpleChanges, ViewChild
} from '@angular/core';

export class Hero {
  constructor(public name: string) {}
}

@Component({
  selector: 'on-changes',
  template: `
  <div class="hero">
    <p>{{hero.name}} can {{power}}</p>

    <h4>-- Change Log --</h4>
    <div *ngFor="let chg of changeLog">{{chg}}</div>
  </div>
  `,
  styles: [
    '.hero {background: LightYellow; padding: 8px; margin-top: 8px}',
    'p {background: Yellow; padding: 8px; margin-top: 8px}'
  ]
})
export class OnChangesComponent implements OnChanges,OnInit,OnDestroy,AfterContentInit,AfterViewInit {
  @Input() hero: Hero;
  @Input() power: string;
  changeLog: string[] = [];

   constructor()
   {
     console.log('constructor called');
     let status = this.hero ? 'is' : 'is not';
     console.log("hero "+status+" known at time of construction");
   }
 

  ngOnChanges(changes: SimpleChanges) {
     console.log(`OnChanges called`);
    for (let propName in changes) {
      let chng = changes[propName];
      let cur  = JSON.stringify(chng.currentValue);
      let prev = JSON.stringify(chng.previousValue);
      this.changeLog.push(`${propName}: currentValue = ${cur}, previousValue = ${prev}`);
      console.log(`${propName}: currentValue = ${cur}, previousValue = ${prev}`);
    }
  }
  
  ngOnInit() { console.log(`OnInit called:`+' hero='+this.hero.name+' , power='+this.power); }
  
  ngOnDestroy() { console.log(`OnDestroy called`);  }
  
  
  
  // Beware! Called frequently!
  // Called in every change detection cycle anywhere on the page
  ngDoCheck() { console.log(`DoCheck`); }

  ngAfterContentInit() { console.log(`AfterContentInit`);  }
  
  // Beware! Called frequently!
  // Called in every change detection cycle anywhere on the page
  ngAfterContentChecked() {
    // Component content has been Checked
    console.log(`AfterContentChecked`); 
  }
  ngAfterViewInit() { console.log(`AfterViewInit`); }
  
  
  // Beware! Called frequently!
  // Called in every change detection cycle anywhere on the page
  ngAfterViewChecked() {
    // Component views have been checked
    console.log(`AfterViewChecked`); 
  }
  


  reset() { this.changeLog.length = 0; }
}



