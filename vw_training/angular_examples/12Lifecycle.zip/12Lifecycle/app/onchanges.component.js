"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Hero = (function () {
    function Hero(name) {
        this.name = name;
    }
    return Hero;
}());
exports.Hero = Hero;
var OnChangesComponent = (function () {
    function OnChangesComponent() {
        this.changeLog = [];
        console.log('constructor called');
        var status = this.hero ? 'is' : 'is not';
        console.log("hero " + status + " known at time of construction");
    }
    OnChangesComponent.prototype.ngOnChanges = function (changes) {
        console.log("OnChanges called");
        for (var propName in changes) {
            var chng = changes[propName];
            var cur = JSON.stringify(chng.currentValue);
            var prev = JSON.stringify(chng.previousValue);
            this.changeLog.push(propName + ": currentValue = " + cur + ", previousValue = " + prev);
            console.log(propName + ": currentValue = " + cur + ", previousValue = " + prev);
        }
    };
    OnChangesComponent.prototype.ngOnInit = function () { console.log("OnInit called:" + ' hero=' + this.hero.name + ' , power=' + this.power); };
    OnChangesComponent.prototype.ngOnDestroy = function () { console.log("OnDestroy called"); };
    // Beware! Called frequently!
    // Called in every change detection cycle anywhere on the page
    OnChangesComponent.prototype.ngDoCheck = function () { console.log("DoCheck"); };
    OnChangesComponent.prototype.ngAfterContentInit = function () { console.log("AfterContentInit"); };
    // Beware! Called frequently!
    // Called in every change detection cycle anywhere on the page
    OnChangesComponent.prototype.ngAfterContentChecked = function () {
        // Component content has been Checked
        console.log("AfterContentChecked");
    };
    OnChangesComponent.prototype.ngAfterViewInit = function () { console.log("AfterViewInit"); };
    // Beware! Called frequently!
    // Called in every change detection cycle anywhere on the page
    OnChangesComponent.prototype.ngAfterViewChecked = function () {
        // Component views have been checked
        console.log("AfterViewChecked");
    };
    OnChangesComponent.prototype.reset = function () { this.changeLog.length = 0; };
    return OnChangesComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Hero)
], OnChangesComponent.prototype, "hero", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], OnChangesComponent.prototype, "power", void 0);
OnChangesComponent = __decorate([
    core_1.Component({
        selector: 'on-changes',
        template: "\n  <div class=\"hero\">\n    <p>{{hero.name}} can {{power}}</p>\n\n    <h4>-- Change Log --</h4>\n    <div *ngFor=\"let chg of changeLog\">{{chg}}</div>\n  </div>\n  ",
        styles: [
            '.hero {background: LightYellow; padding: 8px; margin-top: 8px}',
            'p {background: Yellow; padding: 8px; margin-top: 8px}'
        ]
    }),
    __metadata("design:paramtypes", [])
], OnChangesComponent);
exports.OnChangesComponent = OnChangesComponent;
//# sourceMappingURL=onchanges.component.js.map