import { Component } from '@angular/core';
import { Book } from './model/book';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  book:Book;
  bid:number;
  title = 'template-form-app';

  constructor()
  {
    this.bid=1;
    this.book =  new Book(this.bid,'','');
  }


  newBook():void
  {
    this.book = new Book(this.bid++,'','');
  }

  submitform(form:any):void
  {
    console.log('form submitted..');
    console.log('book:'+this.book.bookid+","+this.book.bookname+","+this.book.bookauthor);
    console.log(form);
    console.log(form.value.bookid);
    console.log(form.value.bookname);
    console.log(form.value.bookauthor);
  }

 }
