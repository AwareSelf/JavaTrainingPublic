"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Hero {
    constructor() {
        this.id = 0;
        this.name = 'nama';
    }
}
exports.Hero = Hero;
class Address {
    constructor() {
        this.street = 's';
        this.city = 'c';
        this.state = 'st';
        this.zip = 'z';
    }
}
exports.Address = Address;
exports.heroes = [
    {
        id: 1,
        name: 'Whirlwind',
        addresses: [
            { street: '123 Main', city: 'Anywhere', state: 'CA', zip: '94801' },
            { street: '456 Maple', city: 'Somewhere', state: 'VA', zip: '23226' },
        ]
    },
    {
        id: 2,
        name: 'Bombastic',
        addresses: [
            { street: '789 Elm', city: 'Smallville', state: 'OH', zip: '04501' },
        ]
    },
    {
        id: 3,
        name: 'Magneta',
        addresses: []
    },
];
exports.states = ['CA', 'MD', 'OH', 'VA'];
/*
Copyright 2017 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/ 
//# sourceMappingURL=data-model.js.map