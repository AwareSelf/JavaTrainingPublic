import { Component } from '@angular/core';
import { Hero, heroes } from './data-model';

@Component({
  selector: 'my-app',
  template: '<hero-detail1 [hero]=myhero></hero-detail1>'
})
export class AppComponent {

   myhero: Hero = heroes[0];

 
}
