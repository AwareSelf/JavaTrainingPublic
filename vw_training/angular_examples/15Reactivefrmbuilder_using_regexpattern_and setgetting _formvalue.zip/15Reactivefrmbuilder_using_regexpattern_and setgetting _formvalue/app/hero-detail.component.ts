import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { states } from './data-model';

@Component({
  selector: 'hero-detail',
  templateUrl: 'app/hero-detail.component.html'
})

export class HeroDetailComponent {
  heroForm: FormGroup; // <--- heroForm is of type FormGroup
  states = states;
  streetPattern = "^[a-z]{8,15}$";
  
  constructor(private fb: FormBuilder) { // <--- inject FormBuilder
    this.createForm();
  }

  createForm() {
   // this.heroForm = this.fb.group({
   //  name: '', // <--- the FormControl called "name"
   // });
  

   this.heroForm = this.fb.group({
        name: ['', Validators.required ],
       address: this.fb.group({ // <-- the child FormGroup
        street: ['',Validators.pattern(this.streetPattern)],
        city: '',
        state: '',
        zip: ''
        }),
       power: '',
       sidekick: ''
    });
  }
}