import { combineLatestAll } from './combineLatestAll';

/**
 * @deprecated Renamed to {@link combineLatestAll}. Will be removed in v8.
 */
export const combineAll = combineLatestAll;
