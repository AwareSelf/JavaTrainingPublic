package constructorinjection;
public interface GreetingService 
{
	public void sayGreeting();
}
