package com.nama.springboot.firstdemo.restful;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nama.springboot.firstdemo.dao.BookDao;
import com.nama.springboot.firstdemo.model.Book;

@RestController
public class BookRestController {
	
	@Autowired
	BookDao bookdao;
	
	@GetMapping("book/{bookid}")
	public Book getBook(@PathVariable int bookid)
	{
	    Book b =  this.bookdao.getBook(bookid);	
	    return b;
	}
	
	
	@PostMapping("addbook")
	public String addBook(@RequestBody Book b)
	{
		boolean r = this.bookdao.addBook(b);
		
		if(r)
		{
			return "Book with bookid:"+b.getBookId()+" added successfully..";
		}
		else
		{
			return "Not able to add book with bookid:"+b.getBookId();
		}
		
	}
	
	@GetMapping("allbooks")
	public List<Book> getAllBooks()
	{
		return this.bookdao.getAllBooks();
	}
	
//	org.springframework.web.bind.annotation.DeleteMapping
	@DeleteMapping("rembook")
	public String removeBook(@RequestBody Book b)
	{
		boolean status =this.bookdao.removeBook(b);
		
		if(status)
		{
			return "Book with bookid:"+b.getBookId()+" deleted successfully";
		}
		else
		{
			return "Not able to delete Book with bookid:"+b.getBookId();
		}
		
	}
	
	@DeleteMapping("rembook/{bookid}")
	public String removeBook(@PathVariable int bookid)
	{
		boolean status =this.bookdao.removeBook1(bookid);
		
		if(status)
		{
			return "Book with bookid:"+bookid+" deleted successfully";
		}
		else
		{
			return "Not able to delete Book with bookid:"+bookid;
		}
		
	}
	
	

}
